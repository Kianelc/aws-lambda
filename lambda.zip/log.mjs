export function log(msg) {
    console.log(`Adicionando log via função ${msg}`);
}